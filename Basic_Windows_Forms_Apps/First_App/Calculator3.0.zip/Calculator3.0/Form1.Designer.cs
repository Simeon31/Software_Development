﻿
namespace Calculator3._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.num07 = new System.Windows.Forms.Button();
            this.calculatorDisplay = new System.Windows.Forms.Label();
            this.num08 = new System.Windows.Forms.Button();
            this.num09 = new System.Windows.Forms.Button();
            this.num04 = new System.Windows.Forms.Button();
            this.num01 = new System.Windows.Forms.Button();
            this.num06 = new System.Windows.Forms.Button();
            this.num05 = new System.Windows.Forms.Button();
            this.num03 = new System.Windows.Forms.Button();
            this.num02 = new System.Windows.Forms.Button();
            this.zerobutton = new System.Windows.Forms.Button();
            this.equalbutton = new System.Windows.Forms.Button();
            this.decimalbutton = new System.Windows.Forms.Button();
            this.multiplybutton = new System.Windows.Forms.Button();
            this.plusbutton = new System.Windows.Forms.Button();
            this.devidebutton = new System.Windows.Forms.Button();
            this.minusbutton = new System.Windows.Forms.Button();
            this.clearbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // num07
            // 
            this.num07.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num07.Location = new System.Drawing.Point(22, 138);
            this.num07.Name = "num07";
            this.num07.Size = new System.Drawing.Size(62, 49);
            this.num07.TabIndex = 0;
            this.num07.Text = "7";
            this.num07.UseVisualStyleBackColor = true;
            this.num07.Click += new System.EventHandler(this.num07_Click);
            // 
            // calculatorDisplay
            // 
            this.calculatorDisplay.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.calculatorDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.calculatorDisplay.ForeColor = System.Drawing.Color.Maroon;
            this.calculatorDisplay.Location = new System.Drawing.Point(20, 22);
            this.calculatorDisplay.Name = "calculatorDisplay";
            this.calculatorDisplay.Size = new System.Drawing.Size(319, 48);
            this.calculatorDisplay.TabIndex = 1;
            this.calculatorDisplay.Text = "0";
            // 
            // num08
            // 
            this.num08.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num08.Location = new System.Drawing.Point(109, 138);
            this.num08.Name = "num08";
            this.num08.Size = new System.Drawing.Size(62, 49);
            this.num08.TabIndex = 2;
            this.num08.Text = "8";
            this.num08.UseVisualStyleBackColor = true;
            this.num08.Click += new System.EventHandler(this.num08_Click);
            // 
            // num09
            // 
            this.num09.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num09.Location = new System.Drawing.Point(197, 138);
            this.num09.Name = "num09";
            this.num09.Size = new System.Drawing.Size(62, 49);
            this.num09.TabIndex = 3;
            this.num09.Text = "9";
            this.num09.UseVisualStyleBackColor = true;
            this.num09.Click += new System.EventHandler(this.num09_Click);
            // 
            // num04
            // 
            this.num04.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num04.Location = new System.Drawing.Point(22, 208);
            this.num04.Name = "num04";
            this.num04.Size = new System.Drawing.Size(62, 49);
            this.num04.TabIndex = 4;
            this.num04.Text = "4";
            this.num04.UseVisualStyleBackColor = true;
            this.num04.Click += new System.EventHandler(this.num04_Click);
            // 
            // num01
            // 
            this.num01.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num01.Location = new System.Drawing.Point(22, 267);
            this.num01.Name = "num01";
            this.num01.Size = new System.Drawing.Size(62, 49);
            this.num01.TabIndex = 5;
            this.num01.Text = "1";
            this.num01.UseVisualStyleBackColor = true;
            this.num01.Click += new System.EventHandler(this.num01_Click);
            // 
            // num06
            // 
            this.num06.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num06.Location = new System.Drawing.Point(197, 208);
            this.num06.Name = "num06";
            this.num06.Size = new System.Drawing.Size(62, 49);
            this.num06.TabIndex = 6;
            this.num06.Text = "6";
            this.num06.UseVisualStyleBackColor = true;
            this.num06.Click += new System.EventHandler(this.num06_Click);
            // 
            // num05
            // 
            this.num05.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num05.Location = new System.Drawing.Point(109, 208);
            this.num05.Name = "num05";
            this.num05.Size = new System.Drawing.Size(62, 49);
            this.num05.TabIndex = 7;
            this.num05.Text = "5";
            this.num05.UseVisualStyleBackColor = true;
            this.num05.Click += new System.EventHandler(this.num05_Click);
            // 
            // num03
            // 
            this.num03.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num03.Location = new System.Drawing.Point(197, 267);
            this.num03.Name = "num03";
            this.num03.Size = new System.Drawing.Size(62, 49);
            this.num03.TabIndex = 9;
            this.num03.Text = "3";
            this.num03.UseVisualStyleBackColor = true;
            this.num03.Click += new System.EventHandler(this.num03_Click);
            // 
            // num02
            // 
            this.num02.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.num02.Location = new System.Drawing.Point(109, 267);
            this.num02.Name = "num02";
            this.num02.Size = new System.Drawing.Size(62, 49);
            this.num02.TabIndex = 10;
            this.num02.Text = "2";
            this.num02.UseVisualStyleBackColor = true;
            this.num02.Click += new System.EventHandler(this.num02_Click);
            // 
            // zerobutton
            // 
            this.zerobutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.zerobutton.Location = new System.Drawing.Point(22, 335);
            this.zerobutton.Name = "zerobutton";
            this.zerobutton.Size = new System.Drawing.Size(149, 48);
            this.zerobutton.TabIndex = 11;
            this.zerobutton.Text = "0";
            this.zerobutton.UseVisualStyleBackColor = true;
            this.zerobutton.Click += new System.EventHandler(this.zerobutton_Click);
            // 
            // equalbutton
            // 
            this.equalbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.equalbutton.Location = new System.Drawing.Point(279, 334);
            this.equalbutton.Name = "equalbutton";
            this.equalbutton.Size = new System.Drawing.Size(62, 48);
            this.equalbutton.TabIndex = 12;
            this.equalbutton.Text = "=";
            this.equalbutton.UseVisualStyleBackColor = true;
            this.equalbutton.Click += new System.EventHandler(this.equalbutton_Click);
            // 
            // decimalbutton
            // 
            this.decimalbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.decimalbutton.Location = new System.Drawing.Point(197, 334);
            this.decimalbutton.Name = "decimalbutton";
            this.decimalbutton.Size = new System.Drawing.Size(62, 49);
            this.decimalbutton.TabIndex = 13;
            this.decimalbutton.Text = ".";
            this.decimalbutton.UseVisualStyleBackColor = true;
            this.decimalbutton.Click += new System.EventHandler(this.decimalbutton_Click);
            // 
            // multiplybutton
            // 
            this.multiplybutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.multiplybutton.Location = new System.Drawing.Point(279, 151);
            this.multiplybutton.Name = "multiplybutton";
            this.multiplybutton.Size = new System.Drawing.Size(62, 49);
            this.multiplybutton.TabIndex = 14;
            this.multiplybutton.Text = "x";
            this.multiplybutton.UseVisualStyleBackColor = true;
            this.multiplybutton.Click += new System.EventHandler(this.multiplybutton_Click);
            // 
            // plusbutton
            // 
            this.plusbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.plusbutton.Location = new System.Drawing.Point(279, 267);
            this.plusbutton.Name = "plusbutton";
            this.plusbutton.Size = new System.Drawing.Size(62, 49);
            this.plusbutton.TabIndex = 15;
            this.plusbutton.Text = "+";
            this.plusbutton.UseVisualStyleBackColor = true;
            this.plusbutton.Click += new System.EventHandler(this.plusbutton_Click);
            // 
            // devidebutton
            // 
            this.devidebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.devidebutton.Location = new System.Drawing.Point(279, 85);
            this.devidebutton.Name = "devidebutton";
            this.devidebutton.Size = new System.Drawing.Size(62, 49);
            this.devidebutton.TabIndex = 16;
            this.devidebutton.Text = "/";
            this.devidebutton.UseVisualStyleBackColor = true;
            this.devidebutton.Click += new System.EventHandler(this.devidebutton_Click);
            // 
            // minusbutton
            // 
            this.minusbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.minusbutton.Location = new System.Drawing.Point(279, 208);
            this.minusbutton.Name = "minusbutton";
            this.minusbutton.Size = new System.Drawing.Size(62, 49);
            this.minusbutton.TabIndex = 17;
            this.minusbutton.Text = "-";
            this.minusbutton.UseVisualStyleBackColor = true;
            this.minusbutton.Click += new System.EventHandler(this.minusbutton_Click);
            // 
            // clearbutton
            // 
            this.clearbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clearbutton.Location = new System.Drawing.Point(22, 85);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(237, 47);
            this.clearbutton.TabIndex = 18;
            this.clearbutton.Text = "AC";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(368, 406);
            this.Controls.Add(this.clearbutton);
            this.Controls.Add(this.minusbutton);
            this.Controls.Add(this.devidebutton);
            this.Controls.Add(this.plusbutton);
            this.Controls.Add(this.multiplybutton);
            this.Controls.Add(this.decimalbutton);
            this.Controls.Add(this.equalbutton);
            this.Controls.Add(this.zerobutton);
            this.Controls.Add(this.num02);
            this.Controls.Add(this.num03);
            this.Controls.Add(this.num05);
            this.Controls.Add(this.num06);
            this.Controls.Add(this.num01);
            this.Controls.Add(this.num04);
            this.Controls.Add(this.num09);
            this.Controls.Add(this.num08);
            this.Controls.Add(this.calculatorDisplay);
            this.Controls.Add(this.num07);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button num07;
        private System.Windows.Forms.Label calculatorDisplay;
        private System.Windows.Forms.Button num08;
        private System.Windows.Forms.Button num09;
        private System.Windows.Forms.Button num04;
        private System.Windows.Forms.Button num01;
        private System.Windows.Forms.Button num06;
        private System.Windows.Forms.Button num05;
        private System.Windows.Forms.Button num03;
        private System.Windows.Forms.Button num02;
        private System.Windows.Forms.Button zerobutton;
        private System.Windows.Forms.Button equalbutton;
        private System.Windows.Forms.Button decimalbutton;
        private System.Windows.Forms.Button multiplybutton;
        private System.Windows.Forms.Button plusbutton;
        private System.Windows.Forms.Button devidebutton;
        private System.Windows.Forms.Button minusbutton;
        private System.Windows.Forms.Button clearbutton;
    }
}


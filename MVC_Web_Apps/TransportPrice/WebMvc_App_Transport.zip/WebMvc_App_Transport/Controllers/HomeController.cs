﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebMvc_App_Transport.Model;
using WebMvc_App_Transport.Models;

namespace WebMvc_App_Transport.Controllers
{
    public class HomeController : Controller
    {
        
        public ActionResult Index(TransportPrice transportPrice)
        {
            return View(transportPrice);
        }

        [HttpPost]
        public ActionResult Calculate(TransportPrice transportPrice)
        {
            transportPrice.CalculateLowestTransportPrice();

            return RedirectToAction("Index", transportPrice);
        }
    }
}
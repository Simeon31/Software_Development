﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebMvc_App_Transport.Models
{
    public interface IVehicle
    {
        int Distance { get; set; }
        double Price { get;}
    }
}

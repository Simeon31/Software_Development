﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebMvc_App_Transport.Models
{
    public class Taxi : IVehicle
    {
        private const double startTaxiPrice = 0.70;

        public int Distance { get; set; }
        public double Price
        {
            get
            {
                return startTaxiPrice;
            }
        }
    }
}
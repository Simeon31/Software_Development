﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Web.Mvc;
using WebMvc_App_Transport.Models;

namespace WebMvc_App_Transport.Model
{
    public class TransportPrice : IVehicle
    {
        private string dayTime;
        private double cheapestPrice;

        public int Distance { get; set; }
        public double Price { get; set; }

        public TransportPrice()
        {
            Distance = 0;
            Price = 0.0;
            DayTime = String.Empty;
            cheapestPrice = 0.0;
        }
        public string DayTime
        {
            get
            {
                return dayTime;
            }
            set
            {
                dayTime = value;
            }
        }
        public double CheapestPrice
        {
            get
            {
                return cheapestPrice;
            }
            set
            {
                cheapestPrice = value;
            }
        }

        public double CalculateLowestTransportPrice()
        {
            IVehicle taxi = new Taxi();
            IVehicle bus = new Bus();
            IVehicle train = new Train();

            switch (DayTime)
            {

                case "Day":
                    if (Distance <= 20)
                    {
                        taxi.Distance = Distance;
                        double dailyTaxiPrice = 0.79;
                        Price = taxi.Price + (taxi.Distance * dailyTaxiPrice);
                        CheapestPrice = Price;
                    }
                    else if (Distance <= 100)
                    {
                        bus.Distance = Distance;
                        Price = bus.Price * bus.Distance;
                        CheapestPrice = Price;
                    }
                    else if (Distance > 100)
                    {
                        train.Distance = Distance;
                        Price = train.Price * train.Distance;
                        CheapestPrice = Price;
                    }
                    break;

                case "Night":
                    if (Distance <= 20)
                    {
                        taxi.Distance = Distance;
                        double nightlyTaxiPrice = 0.90;
                        if (Distance == 0)
                        {
                            CheapestPrice = nightlyTaxiPrice;
                        }
                        else
                        {
                            Price = taxi.Price + (taxi.Distance * nightlyTaxiPrice);
                            CheapestPrice = Price;
                        }
                    }
                    else if (Distance <= 100)
                    {
                        bus.Distance = Distance;
                        Price = bus.Price * bus.Distance;
                        CheapestPrice = Price;
                    }
                    else if (Distance > 100)
                    {
                        train.Distance = Distance;
                        Price = train.Price * train.Distance;
                        CheapestPrice = Price;
                    }
                    break;
            }
            return CheapestPrice;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebMvc_App_Transport.Models
{
    class Bus : IVehicle
    {
        private const double busPrice = 0.09;

        public int Distance { get; set; }


        public double Price
        {
            get
            {
                return busPrice;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebMvc_App_Transport.Models
{
    public class Train : IVehicle
    {
        private const double trainPrice = 0.06;

        public int Distance { get; set; }

        public double Price
        {
            get
            {
                return trainPrice;
            }
        }
    }
}